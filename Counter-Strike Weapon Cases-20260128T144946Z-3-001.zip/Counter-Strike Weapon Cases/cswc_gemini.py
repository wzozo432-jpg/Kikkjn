import os
import json
import random
import datetime
from ursina import *
from ursina.shaders import lit_with_shadows_shader
from PIL import Image, ImageDraw

# ==========================================
# CONFIGURATION & CONSTANTS
# ==========================================
app = Ursina(title="CS:GO Case Simulator", borderless=False)

# BACKGROUND: Light Gray
window.color = color.light_gray

INVENTORY_FILE = "inventory_data.json"
TEXTURE_TEMP_DIR = "temp_skins"

if not os.path.exists(TEXTURE_TEMP_DIR):
    os.makedirs(TEXTURE_TEMP_DIR)

# RARITY SETTINGS
RARITIES = {
    "Common": {"color": color.rgb(75, 105, 255), "chance": 0.42, "hex": "#4b69ff"},     # Blue
    "Uncommon": {"color": color.rgb(136, 71, 255), "chance": 0.23, "hex": "#8847ff"},   # Purple
    "Rare": {"color": color.rgb(211, 44, 230), "chance": 0.16, "hex": "#d32ce6"},       # Pink
    "Ultra-Rare": {"color": color.rgb(235, 75, 75), "chance": 0.12, "hex": "#eb4b4b"},  # Red
    "Mythical": {"color": color.rgb(255, 215, 0), "chance": 0.07, "hex": "#ffd700"}     # Gold
}

WEAR_RANGES = [
    ("Minted", 0.00, 0.07, 0.09),
    ("Polished", 0.07, 0.15, 0.15),
    ("Weathered", 0.15, 0.38, 0.33),
    ("Scuffed", 0.38, 0.45, 0.24),
    ("Rotted", 0.45, 1.00, 0.19)
]

WEAPON_TYPES = {
    "Pistol": ["USP-S", "Desert Eagle"],
    "SMG": ["UMP-45", "Mac-10"],
    "Rifle": ["AK-47", "M4A4"],
    "Sniper": ["AWP", "SSG"],
    "Knife": ["Butterfly", "Karambit"]
}

SKIN_PATTERNS = ["Hydro", "Tiger", "Fade", "Grid", "Abstract"]

# ==========================================
# BACKEND LOGIC
# ==========================================

class SkinGenerator:
    @staticmethod
    def get_wear_name(float_val):
        for name, min_w, max_w, _ in WEAR_RANGES:
            if min_w <= float_val <= max_w:
                return name
        return "Rotted"

    @staticmethod
    def generate_skin_texture(weapon_name, pattern_name, seed, wear_float, rarity_color_hex, size=256):
        """Generates a texture and saves it. Size can be reduced for thumbnails."""
        # Unique filename based on parameters so we don't overwrite
        filename = f"{TEXTURE_TEMP_DIR}/{weapon_name}_{pattern_name}_{seed}_{wear_float:.4f}_{size}.png"
        
        # Optimization: If it exists, don't remake it
        if os.path.exists(filename):
            return filename

        random.seed(seed)
        img = Image.new('RGB', (size, size), color=(20, 20, 20))
        draw = ImageDraw.Draw(img)
        
        base_c = tuple(int(rarity_color_hex.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
        
        # Pattern Logic
        if pattern_name == "Hydro":
            for _ in range(int(40 * (size/256))):
                x, y = random.randint(0, size), random.randint(0, size)
                r = random.randint(int(10*(size/256)), int(50*(size/256)))
                draw.ellipse((x-r, y-r, x+r, y+r), fill=base_c, outline=None)
        elif pattern_name == "Tiger":
            for i in range(0, size, int(20*(size/256))):
                offset = random.randint(-10, 10)
                draw.line((0, i+offset, size, i-offset), fill=base_c, width=int(10*(size/256)))
        elif pattern_name == "Fade":
            for y in range(size):
                r = int(base_c[0] * (y/size))
                g = int(base_c[1] * ((size-y)/size))
                b = int(base_c[2])
                draw.line((0, y, size, y), fill=(r,g,b))
        elif pattern_name == "Grid":
            step = int(32 * (size/256))
            if step < 1: step = 1
            for x in range(0, size, step):
                for y in range(0, size, step):
                    if (x//step + y//step) % 2 == 0:
                        draw.rectangle((x, y, x+step, y+step), fill=base_c)
        elif pattern_name == "Abstract":
            for _ in range(10):
                pts = [(random.randint(0, size), random.randint(0, size)) for _ in range(3)]
                draw.polygon(pts, fill=base_c)

        # Apply Wear
        wear_layer = Image.new('RGBA', (size, size), (0,0,0,0))
        wear_draw = ImageDraw.Draw(wear_layer)
        
        # Adjust noise density for image size
        noise_density = int(wear_float * 5000 * (size/256))
        for _ in range(noise_density):
            x, y = random.randint(0, size-1), random.randint(0, size-1)
            opacity = random.randint(100, 255)
            wear_draw.point((x, y), fill=(30, 30, 30, opacity))

        img.paste(wear_layer, (0,0), wear_layer)
        
        if wear_float > 0.15:
            img = img.point(lambda p: p * (1.0 - (wear_float * 0.4)))

        img.save(filename)
        return filename

class CaseManager:
    def __init__(self):
        self.cases = self._generate_cases()

    def _generate_cases(self):
        cases = [[], [], []]
        used_combos = set() 

        for case_idx in range(3):
            flat_weapons = [w for cat in WEAPON_TYPES.values() for w in cat]
            for weapon in flat_weapons:
                if weapon in WEAPON_TYPES["Knife"]:
                    rarity = "Mythical"
                else:
                    rarity_keys = list(RARITIES.keys())
                    rarity_keys.remove("Mythical")
                    rarity = random.choice(rarity_keys)

                attempts = 0
                while True:
                    pattern = random.choice(SKIN_PATTERNS)
                    combo_id = f"{weapon}_{pattern}"
                    if combo_id not in used_combos:
                        used_combos.add(combo_id)
                        break
                    attempts += 1
                    if attempts > 50: break

                cases[case_idx].append({
                    "weapon": weapon,
                    "pattern": pattern,
                    "rarity": rarity
                })
        return cases

    def get_random_loot(self, case_index):
        """Generates a random item result fully populated with floats."""
        case_content = self.cases[case_index]
        r_weights = [RARITIES[k]["chance"] for k in RARITIES]
        r_names = list(RARITIES.keys())
        won_rarity = random.choices(r_names, weights=r_weights, k=1)[0]
        
        potential_wins = [item for item in case_content if item['rarity'] == won_rarity]
        if not potential_wins: potential_wins = case_content
        won_item_template = random.choice(potential_wins)
        
        w_weights = [x[3] for x in WEAR_RANGES]
        w_ranges = [(x[1], x[2]) for x in WEAR_RANGES]
        chosen_range = random.choices(w_ranges, weights=w_weights, k=1)[0]
        
        float_val = round(random.uniform(chosen_range[0], chosen_range[1]), 10)
        seed = random.randint(0, 999)
        
        return {
            "weapon": won_item_template["weapon"],
            "pattern": won_item_template["pattern"],
            "rarity": won_item_template["rarity"],
            "float": float_val,
            "seed": seed,
            "date": datetime.datetime.now().strftime("%B %d, %Y, %I:%M:%S %p"),
            "case_id": case_index + 1
        }

class Inventory:
    def __init__(self):
        self.items = []
        self.load()
    
    def add(self, item):
        self.items.append(item)
        self.save()
        
    def save(self):
        with open(INVENTORY_FILE, 'w') as f:
            json.dump(self.items, f)
            
    def load(self):
        if os.path.exists(INVENTORY_FILE):
            try:
                with open(INVENTORY_FILE, 'r') as f:
                    self.items = json.load(f)
            except:
                self.items = []
        else:
            self.items = []

    def wipe(self):
        self.items = []
        self.save()
        if os.path.exists(TEXTURE_TEMP_DIR):
            for f in os.listdir(TEXTURE_TEMP_DIR):
                try: os.remove(os.path.join(TEXTURE_TEMP_DIR, f))
                except: pass

# ==========================================
# 3D OBJECT BUILDER
# ==========================================
def build_weapon_model(weapon_name):
    parent = Entity(scale=1)
    
    if weapon_name == "AK-47":
        Entity(parent=parent, model='cube', scale=(0.8, 0.15, 0.1), position=(0,0,0))
        Entity(parent=parent, model='cube', scale=(0.4, 0.05, 0.05), position=(0.5, 0.02, 0))
        Entity(parent=parent, model='cube', scale=(0.15, 0.4, 0.1), position=(0.1, -0.2, 0), rotation=(0,0,15))
        Entity(parent=parent, model='cube', scale=(0.3, 0.12, 0.1), position=(-0.5, -0.05, 0))
    elif weapon_name == "M4A4":
        Entity(parent=parent, model='cube', scale=(0.7, 0.18, 0.1))
        Entity(parent=parent, model='cube', scale=(0.35, 0.06, 0.06), position=(0.4, 0.05, 0))
        Entity(parent=parent, model='cube', scale=(0.1, 0.3, 0.1), position=(0, -0.2, 0)) 
        Entity(parent=parent, model='cube', scale=(0.25, 0.15, 0.1), position=(-0.45, 0, 0))
    elif weapon_name == "AWP":
        Entity(parent=parent, model='cube', scale=(0.9, 0.15, 0.1)) 
        Entity(parent=parent, model='cube', scale=(0.6, 0.04, 0.04), position=(0.6, 0.05, 0)) 
        Entity(parent=parent, model='cube', scale=(0.2, 0.08, 0.1), position=(0, 0.15, 0)) 
        Entity(parent=parent, model='cube', scale=(0.3, 0.15, 0.1), position=(-0.5, -0.05, 0)) 
    elif weapon_name == "SSG":
        Entity(parent=parent, model='cube', scale=(0.7, 0.12, 0.08))
        Entity(parent=parent, model='cube', scale=(0.4, 0.03, 0.03), position=(0.5, 0.02, 0))
        Entity(parent=parent, model='cube', scale=(0.15, 0.06, 0.08), position=(0, 0.1, 0))
    elif weapon_name == "Desert Eagle":
        Entity(parent=parent, model='cube', scale=(0.4, 0.1, 0.08))
        Entity(parent=parent, model='cube', scale=(0.1, 0.2, 0.08), position=(-0.15, -0.1, 0), rotation=(0,0,10))
    elif weapon_name == "USP-S":
        Entity(parent=parent, model='cube', scale=(0.35, 0.08, 0.07))
        Entity(parent=parent, model='cube', scale=(0.2, 0.04, 0.04), position=(0.25, 0, 0))
        Entity(parent=parent, model='cube', scale=(0.09, 0.18, 0.07), position=(-0.15, -0.1, 0))
    elif weapon_name == "Mac-10":
        Entity(parent=parent, model='cube', scale=(0.3, 0.2, 0.15)) 
        Entity(parent=parent, model='cube', scale=(0.08, 0.15, 0.1), position=(-0.05, -0.15, 0)) 
        Entity(parent=parent, model='cube', scale=(0.05, 0.2, 0.05), position=(0.1, -0.15, 0))
    elif weapon_name == "UMP-45":
        Entity(parent=parent, model='cube', scale=(0.5, 0.15, 0.1))
        Entity(parent=parent, model='cube', scale=(0.08, 0.3, 0.08), position=(0.1, -0.2, 0))
    elif weapon_name == "Karambit":
        Entity(parent=parent, model='cube', scale=(0.3, 0.08, 0.02), rotation=(0,0,30))
        Entity(parent=parent, model='cube', scale=(0.15, 0.05, 0.05), position=(-0.2, -0.1, 0), rotation=(0,0,-20))
    elif weapon_name == "Butterfly":
        Entity(parent=parent, model='cube', scale=(0.4, 0.05, 0.02))
        Entity(parent=parent, model='cube', scale=(0.3, 0.03, 0.03), position=(-0.35, 0.03, 0))
        Entity(parent=parent, model='cube', scale=(0.3, 0.03, 0.03), position=(-0.35, -0.03, 0))
    else:
        Entity(parent=parent, model='cube', scale=(0.5, 0.5, 0.5))

    return parent

# ==========================================
# UI & GAME CONTROLLER
# ==========================================

class GameController(Entity):
    def __init__(self):
        super().__init__()
        self.case_manager = CaseManager()
        self.inventory = Inventory()
        self.current_menu = "main"
        
        self.main_menu_ui = Entity(parent=camera.ui)
        self.spin_ui = Entity(parent=camera.ui, enabled=False)
        self.inspect_ui = Entity(parent=camera.ui, enabled=False)
        self.inventory_ui = Entity(parent=camera.ui, enabled=False)
        
        self.setup_main_menu()
        self.setup_spin_ui()
        self.setup_inspect_ui()
        self.setup_inventory_ui()
        
        self.displayed_weapon = None
        self.pivot = Entity()

    def setup_main_menu(self):
        self.case_buttons = []
        Text("SELECT A CASE", parent=self.main_menu_ui, y=0.4, scale=2, origin=(0,0), color=color.black)
        
        for i in range(3):
            b = Button(text=f"CASE #{i+1}", parent=self.main_menu_ui, scale=(0.3, 0.1), position=(0, 0.2 - (i*0.15)), 
                       color=color.azure, on_click=Func(self.start_spin, i))
            self.case_buttons.append(b)

        Button(text="INVENTORY", parent=self.main_menu_ui, scale=(0.2, 0.08), position=(0, -0.3), 
               color=color.orange, on_click=self.show_inventory)

    def setup_spin_ui(self):
        self.spin_container = Entity(parent=self.spin_ui, position=(-0.6, 0, 0))
        self.spin_items = []
        self.spin_cover = Entity(parent=self.spin_ui, model='quad', scale=(0.01, 0.3), color=color.yellow, z=-1)
        self.spinning = False

    def setup_inspect_ui(self):
        # FIX: Just text, no background box
        # Positioned to the left of the screen, Black text
        self.info_text = Text(text="", parent=self.inspect_ui, 
                              origin=(-0.5, 0.5), position=(-0.85, 0.4),
                              scale=1.5, color=color.black, line_height=1.2)
        
        Button(text="BACK TO MENU", parent=self.inspect_ui, scale=(0.2, 0.05), position=(0, -0.45), 
               on_click=self.return_to_menu)

    def setup_inventory_ui(self):
        self.inv_list_entity = Entity(parent=self.inventory_ui)
        Button(text="BACK", parent=self.inventory_ui, scale=(0.15, 0.05), position=(-0.6, 0.4), on_click=self.return_to_menu)
        Button(text="WIPE INVENTORY", parent=self.inventory_ui, scale=(0.2, 0.05), position=(0.6, 0.4), 
               color=color.red, on_click=self.wipe_inventory)

    def start_spin(self, case_index):
        self.current_menu = "spin"
        self.main_menu_ui.disable()
        self.spin_ui.enable()
        
        # 1. Determine Win
        won_item = self.case_manager.get_random_loot(case_index)
        
        # 2. Build Strip (fully populated with random loot)
        items_visual = []
        # Pre-win trash
        for _ in range(25):
            items_visual.append(self.case_manager.get_random_loot(case_index))
        # The Win
        items_visual.append(won_item)
        # Post-win trash
        for _ in range(3):
            items_visual.append(self.case_manager.get_random_loot(case_index))

        # Clear old
        for child in self.spin_container.children:
            destroy(child)
            
        x_off = 0
        self.spin_container.x = 0.6 
        
        # 3. Render Strip
        for item in items_visual:
            c = RARITIES[item['rarity']]['color']
            r_hex = RARITIES[item['rarity']]['hex']
            
            # Generate Thumbnail (Small size for speed)
            thumb_path = SkinGenerator.generate_skin_texture(
                item['weapon'], item['pattern'], item['seed'], item['float'], r_hex, size=64
            )
            
            # Card Base
            e = Entity(parent=self.spin_container, model='quad', color=color.white, texture=thumb_path, 
                       scale=(0.18, 0.18), position=(x_off, 0, 0))
            
            # FIX: Rarity Stripe - Z-index significantly closer (-0.1) so it won't clip
            Entity(parent=e, model='quad', color=c, scale=(1, 0.15), position=(0, -0.425, -0.1))
            
            # Text (White with shadow for readability over pattern)
            t = Text(text=item['weapon'], parent=e, scale=4, origin=(0,0), y=0, color=color.white)
            t.create_background(color=color.rgba(0,0,0,150)) # Small background for text readability
            
            x_off += 0.22

        target_x = - (25 * 0.22) + 0.05 
        self.spin_container.animate_x(target_x, duration=5, curve=curve.out_expo)
        invoke(self.show_inspect, won_item, delay=5.5)

    def show_inspect(self, item_data, from_inventory=False):
        self.spin_ui.disable()
        self.inventory_ui.disable()
        self.inspect_ui.enable()
        self.current_menu = "inspect"
        
        if not from_inventory:
            self.inventory.add(item_data)
            
        if self.displayed_weapon:
            destroy(self.displayed_weapon)
            
        self.displayed_weapon = build_weapon_model(item_data['weapon'])
        self.displayed_weapon.parent = self.pivot
        self.displayed_weapon.scale = 2
        
        # High Res Texture for Inspect
        r_hex = RARITIES[item_data['rarity']]['hex']
        tex_path = SkinGenerator.generate_skin_texture(
            item_data['weapon'], item_data['pattern'], item_data['seed'], item_data['float'], r_hex, size=256
        )
        
        tex = load_texture(tex_path)
        for child in self.displayed_weapon.children:
            child.texture = tex
            child.shader = lit_with_shadows_shader
            
        wear_name = SkinGenerator.get_wear_name(item_data['float'])
        info_string = (
            f"WEAPON: {item_data['weapon']}\n"
            f"SKIN: {item_data['pattern']}\n"
            f"RARITY: {item_data['rarity']}\n"
            f"WEAR: {item_data['float']:.10f} ({wear_name})\n"
            f"SEED: {item_data['seed']}\n"
            f"OBTAINED: {item_data['date']}\n"
            f"CASE: #{item_data['case_id']}"
        )
        self.info_text.text = info_string

    def update(self):
        if self.current_menu == "inspect":
            self.pivot.rotation_y += 20 * time.dt
            self.pivot.rotation_x = 10

    def show_inventory(self):
        self.main_menu_ui.disable()
        self.inventory_ui.enable()
        self.current_menu = "inventory"
        
        for c in self.inv_list_entity.children:
            destroy(c)
            
        start_x = -0.7
        start_y = 0.25
        x = start_x
        y = start_y
        
        for i, item in enumerate(self.inventory.items):
            c = RARITIES[item['rarity']]['color']
            
            # Generate thumb for inventory view
            r_hex = RARITIES[item['rarity']]['hex']
            thumb_path = SkinGenerator.generate_skin_texture(
                item['weapon'], item['pattern'], item['seed'], item['float'], r_hex, size=64
            )
            
            b = Button(parent=self.inv_list_entity, color=color.white, texture=thumb_path, 
                       scale=(0.15, 0.1), position=(x, y))
            
            # Rarity Stripe
            Entity(parent=b, model='quad', color=c, scale=(1, 0.15), position=(0, -0.425, -0.1))
            
            t = Text(text=f"{item['weapon']}\n{item['pattern']}", parent=b, scale=0.8, origin=(0,0), color=color.white, y=0.1)
            t.create_background(color=color.rgba(0,0,0,150))
            
            b.on_click = Func(self.show_inspect, item, True)
            
            x += 0.17
            if x > 0.7:
                x = start_x
                y -= 0.12

    def return_to_menu(self):
        self.inspect_ui.disable()
        self.inventory_ui.disable()
        self.main_menu_ui.enable()
        self.current_menu = "main"
        if self.displayed_weapon:
            destroy(self.displayed_weapon)

    def wipe_inventory(self):
        self.inventory.wipe()
        self.show_inventory()

# ==========================================
# MAIN EXECUTION
# ==========================================

game = GameController()

camera.position = (0, 0, -5)
light = PointLight(parent=camera, position=(0,0,-2))
AmbientLight(color=color.rgba(100, 100, 100, 1))

app.run()