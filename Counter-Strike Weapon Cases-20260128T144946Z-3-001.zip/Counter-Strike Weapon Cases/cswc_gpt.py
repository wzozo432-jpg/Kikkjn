import pygame
import random
import sys

pygame.init()
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("CS Weapon Case Simulator — 2D Edition")

FONT = pygame.font.SysFont("consolas", 24)
BIG_FONT = pygame.font.SysFont("consolas", 40)

CLOCK = pygame.time.Clock()


# ------------------------------------------------------------
# RARITIES + PROBABILITIES
# ------------------------------------------------------------
RARITIES = {
    "Common (Blue)":        0.70,
    "Uncommon (Purple)":    0.20,
    "Rare (Pink)":          0.07,
    "Ultra-Rare (Red)":     0.025,
    "Mythical (Gold)":      0.005
}

RARITY_COLORS = {
    "Common (Blue)":        (80, 140, 255),
    "Uncommon (Purple)":    (170, 80, 255),
    "Rare (Pink)":          (255, 80, 170),
    "Ultra-Rare (Red)":     (255, 60, 60),
    "Mythical (Gold)":      (240, 200, 80)
}

# ------------------------------------------------------------
# WEAR TIERS
# ------------------------------------------------------------
WEAR_TIERS = [
    ("Polished (Factory New)",   0.00, 0.07),
    ("Refined (Minimal Wear)",   0.07, 0.15),
    ("Field-Tested",             0.15, 0.38),
    ("Scuffed (Well-Worn)",      0.38, 0.45),
    ("Rotted (Battle-Scarred)",  0.45, 1.00)
]

# ------------------------------------------------------------
# WEAPON SKINS
# ------------------------------------------------------------
WEAPONS = [
    "AK-47", "M4A1-S", "Glock-18", "USP-S", "Desert Eagle",
    "FAMAS", "AWP", "MP9", "P90", "Five-SeveN"
]

PATTERNS = [
    "Nebula", "Hyper Beast", "Plasma Fade", "Tiger Strike",
    "Crimson Flow", "Ghost Camo", "Toxic Storm", "Nightfall",
    "Obsidian", "Moonstone"
]


# ============================================================
# RANDOM RARITY
# ============================================================
def roll_rarity() -> str:
    r = random.random()
    cumulative = 0
    for rarity, chance in RARITIES.items():
        cumulative += chance
        if r <= cumulative:
            return rarity
    return "Common (Blue)"


# ============================================================
# RANDOM WEAR TIER
# ============================================================
def roll_wear():
    name, low, high = random.choice(WEAR_TIERS)
    return name, round(random.uniform(low, high), 4)


# ============================================================
# MAIN CASE ROLL
# ============================================================
def open_case():
    rarity = roll_rarity()
    weapon = random.choice(WEAPONS)
    pattern = random.choice(PATTERNS)
    wear_name, wear_value = roll_wear()

    return {
        "weapon": weapon,
        "pattern": pattern,
        "rarity": rarity,
        "color": RARITY_COLORS[rarity],
        "wear_name": wear_name,
        "wear": wear_value
    }


# ============================================================
# DRAW TEXT HELPER
# ============================================================
def draw_text(text, x, y, color=(255,255,255), center=False):
    surf = FONT.render(text, True, color)
    rect = surf.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    screen.blit(surf, rect)


# ============================================================
# MENU SCREEN
# ============================================================
def menu_screen():
    running = True
    while running:
        screen.fill((15, 18, 25))

        title = BIG_FONT.render("CS Weapon Case Simulator (2D)", True, (255,255,255))
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 120))

        draw_text("Press SPACE to open a case", WIDTH//2, 300, (180,180,180), center=True)
        draw_text("Press ESC to quit", WIDTH//2, 340, (120,120,120), center=True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
                if event.key == pygame.K_SPACE:
                    return  # go open case

        pygame.display.flip()
        CLOCK.tick(60)


# ============================================================
# RESULT SCREEN
# ============================================================
def result_screen(item):
    running = True
    while running:
        screen.fill((12, 14, 20))

        # Draw weapon card rectangle
        pygame.draw.rect(screen, item["color"], (180, 130, 540, 260), border_radius=12)
        pygame.draw.rect(screen, (255,255,255), (180, 130, 540, 260), 3, border_radius=12)

        # Write weapon data
        draw_text(f"Weapon: {item['weapon']}", 200, 150)
        draw_text(f"Pattern: {item['pattern']}", 200, 190)
        draw_text(f"Rarity: {item['rarity']}", 200, 230, item["color"])
        draw_text(f"Wear: {item['wear_name']}  ({item['wear']})", 200, 270)

        draw_text("Press SPACE to open another case", WIDTH//2, 450, (200,200,200), center=True)
        draw_text("Press ESC to return to main menu", WIDTH//2, 490, (150,150,150), center=True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "menu"
                if event.key == pygame.K_SPACE:
                    return "again"

        pygame.display.flip()
        CLOCK.tick(60)


# ============================================================
# MAIN LOOP
# ============================================================
while True:
    menu_screen()

    item = open_case()
    result = result_screen(item)

    if result == "menu":
        continue
    elif result == "again":
        continue
